import React from 'react';


function Destino(){
   return (
    <div className="destinos">
          <div>
         <h1>TORONTO</h1>
         </div>

        <div>
        <img src="/Destinos/img/TORONTO/TORONTO01.jfif" alt="TORONTO01" />
        <img src="/Destinos/img/TORONTO/TORONTO01.jfif" alt="TORONTO02" />
        <img src="/Destinos/img/TORONTO/TORONTO01.jfif" alt="TORONTO03" />
         </div>

         <div>
        <p>
            Toronto é a maior cidade e maior centro financeiro do Canadá, além de ser a capital da província canadense de Ontário. Com uma população estimada de 2.731.571 de habitantes em 2016, é a quarta cidade mais populosa da América do Norte depois da Cidade do México, Nova York e Los Angeles. Toronto é a cidade mais importante da região metropolitana de Toronto, a região metropolitana mais populosa do Canadá, e âncora da Golden Horseshoe, uma região urbanizada em Ontário que abriga cerca de 9,2 milhões de pessoas, ou mais de 26% da população do Canadá.
        </p>
        
        </div>

         <div>
         <h1>MANCHESTER</h1>
         </div>

         <div>
        <img src="/Destinos/img/MANCHESTER/MAN01.jfif" alt="MAN01" />
        <img src="/Destinos/img/MANCHESTER/MAN02.jfif" alt="MAN02" />
        <img src="/Destinos/img/MANCHESTER/MAN03.jfif" alt="MAN03" />
        </div>

        <div>
        <p>
            Toronto é a maior cidade e maior centro financeiro do Canadá, além de ser a capital da província canadense de Ontário. Com uma população estimada de 2.731.571 de habitantes em 2016, é a quarta cidade mais populosa da América do Norte depois da Cidade do México, Nova York e Los Angeles. Toronto é a cidade mais importante da região metropolitana de Toronto, a região metropolitana mais populosa do Canadá, e âncora da Golden Horseshoe, uma região urbanizada em Ontário que abriga cerca de 9,2 milhões de pessoas, ou mais de 26% da população do Canadá.
        </p>
        </div>

         <div>
         <h1>OSLO</h1>
         </div>

        <div>
        <img src="/DESITNOS/IMG/OSLO/OSLO01.jfif" alt="OSLO01" />
        <img src="/Destinos/img/OSLO/OSLO02.jfif" alt="OSLO02" />
        <img src="/Destinos/img/OSLO/OSLO03.jfif" alt="OSLO03" />
        </div>

        <div>
        <p>
            Toronto é a maior cidade e maior centro financeiro do Canadá, além de ser a capital da província canadense de Ontário. Com uma população estimada de 2.731.571 de habitantes em 2016, é a quarta cidade mais populosa da América do Norte depois da Cidade do México, Nova York e Los Angeles. Toronto é a cidade mais importante da região metropolitana de Toronto, a região metropolitana mais populosa do Canadá, e âncora da Golden Horseshoe, uma região urbanizada em Ontário que abriga cerca de 9,2 milhões de pessoas, ou mais de 26% da população do Canadá.
        </p>
        </div>

    </div>
  );
}

export default Destino;

