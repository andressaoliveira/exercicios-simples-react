import React from 'react';

export default class ListaItens extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      valor: null
    };
  }
  
}